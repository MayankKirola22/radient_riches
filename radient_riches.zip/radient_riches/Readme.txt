1. use "npm i" to install all the required packages.
2. run the project using "npm start" command.