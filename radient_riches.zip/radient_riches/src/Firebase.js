import { initializeApp } from "firebase/app";

const firebaseConfig = {
    apiKey: "AIzaSyDBWFcXXb9kYl3da61SambPs8UsvvPfZTE",
    authDomain: "radient-riches-assignment.firebaseapp.com",
    projectId: "radient-riches-assignment",
    storageBucket: "radient-riches-assignment.appspot.com",
    messagingSenderId: "987261835692",
    appId: "1:987261835692:web:9135163370f1b102c14209"
  };

  const app = initializeApp(firebaseConfig);